import json
import os

MEMORY_FILE = os.path.join(os.path.dirname(__file__), "../data/assistant_memory.json")

def load_memory():
    try:
        with open(MEMORY_FILE, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {"tasks": [], "preferences": {}}

def save_memory(memory):
    os.makedirs(os.path.dirname(MEMORY_FILE), exist_ok=True)
    with open(MEMORY_FILE, "w") as f:
        json.dump(memory, f, indent=4)
