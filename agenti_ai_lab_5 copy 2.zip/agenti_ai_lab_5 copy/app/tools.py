import os
import webbrowser
from .persona import format_message

def open_file(path: str):
    if os.path.exists(path):
        os.startfile(path)  # Windows only
        return format_message(f"Opened file: {path}")
    return format_message(f"File '{path}' not found")

def open_url(url: str):
    webbrowser.open(url)
    return format_message(f"Opened URL: {url}")
