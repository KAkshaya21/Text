persona = {
    "name": "Aiden",
    "role": "Smart Personal Assistant",
    "tone": "friendly"  # friendly / formal
}

def set_persona(name: str, tone: str):
    persona["name"] = name
    persona["tone"] = tone

def format_message(message: str) -> str:
    if persona["tone"] == "friendly":
        return f"{persona['name']}: {message}"
    else:
        return f"{persona['name']} ({persona['role']}): {message}"
