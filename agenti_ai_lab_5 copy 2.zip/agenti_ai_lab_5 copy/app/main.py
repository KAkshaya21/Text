import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from .tasks import add_task, list_tasks, complete_task, suggest_next_task
from .persona import set_persona, format_message
from .tools import open_file, open_url
from .memory_manager import load_memory, save_memory

app = FastAPI(title="Smart Personal Assistant API",
              description="Rule-based AI agent with persona and tool execution",
              version="1.0")

memory = load_memory()

# -------------------------
# Request Models
# -------------------------
class TaskRequest(BaseModel):
    title: str
    priority: int
    due_hours: int

class CommandRequest(BaseModel):
    command: str

# -------------------------
# Persona Endpoints
# -------------------------
@app.post("/set_persona")
def api_set_persona(name: str, tone: str):
    set_persona(name, tone)
    return {"message": format_message(f"Persona set: {name}, tone: {tone}")}

# -------------------------
# Task Endpoints
# -------------------------
@app.post("/add_task")
def api_add_task(task: TaskRequest):
    return {"message": add_task(task.title, task.priority, task.due_hours)}

@app.get("/list_tasks")
def api_list_tasks():
    tasks, msg = list_tasks()
    return {"tasks": tasks, "message": msg}

@app.post("/complete_task/{task_title}")
def api_complete_task(task_title: str):
    msg = complete_task(task_title)
    if "not found" in msg:
        raise HTTPException(status_code=404, detail=msg)
    return {"message": msg}

@app.get("/suggest_task")
def api_suggest_task():
    task, msg = suggest_next_task()
    return {"suggested_task": task, "message": msg}

# -------------------------
# Tool Execution
# -------------------------
@app.post("/execute_command")
def api_execute_command(req: CommandRequest):
    cmd = req.command.lower()

    # PDF
    if cmd.endswith(".pdf") or (cmd.startswith("http") and cmd.endswith(".pdf")):
        return {"message": open_file(cmd) if os.path.exists(cmd) else open_url(cmd)}

    # URL
    if cmd.startswith("http"):
        return {"message": open_url(cmd)}

    # Task commands
    if "list tasks" in cmd:
        tasks, msg = list_tasks()
        return {"tasks": tasks, "message": msg}
    if "suggest task" in cmd:
        task, msg = suggest_next_task()
        return {"suggested_task": task, "message": msg}

    return {"message": format_message("Command not recognized. I can open PDFs, URLs, or manage tasks.")}
