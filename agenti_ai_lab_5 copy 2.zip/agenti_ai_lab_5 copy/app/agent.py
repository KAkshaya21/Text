from app.persona import Persona
from app.tools import write_file, decide
from app.memory import Memory


class Agent:
    def __init__(self):
        self.persona = Persona()
        self.memory = Memory()

    # -------- REASONING STEP --------
    def reason(self, message: str):
        msg = message.lower()

        if "what do you remember" in msg:
            return "recall_memory"

        if msg.startswith("remember"):
            return "store_memory"

        if "create" in msg and "file" in msg:
            return "write_file"

        if "decide between" in msg:
            return "decision"

        return "chat"

    # -------- MAIN RUN FUNCTION --------
    def run(self, message: str):
        action = self.reason(message)
        msg = message.lower()

        # -------- MEMORY RETRIEVE --------
        if action == "recall_memory":
            memories = self.memory.get_facts()
            return self.persona.reply(f"I remember: {memories}")

        # -------- MEMORY STORE --------
        if action == "store_memory":
            info = message[len("remember"):].strip()
            self.memory.save_fact(info)
            return self.persona.reply("I will remember that.")

        # -------- FILE TOOL --------
        if action == "write_file":
            content = message.replace("create a file and write", "").strip()
            write_file("output.txt", content)
            return self.persona.reply(
                "File created and text written successfully."
            )

        # -------- DECISION TOOL --------
        if action == "decision":
            options = msg.replace("decide between", "").strip()
            result = decide(options)
            return self.persona.reply(result)

        # -------- DEFAULT --------
        return self.persona.reply("Message received. No tool required.")
