from datetime import datetime, timedelta
from .memory_manager import load_memory, save_memory
from .persona import format_message

memory = load_memory()

def add_task(title: str, priority: int, due_hours: int):
    task = {
        "title": title,
        "priority": priority,
        "due_time": (datetime.now() + timedelta(hours=due_hours)).isoformat(),
        "completed": False
    }
    memory["tasks"].append(task)
    save_memory(memory)
    return format_message(f"Task '{title}' added!")

def list_tasks():
    tasks = sorted(memory["tasks"], key=lambda x: (x["completed"], x["priority"], x["due_time"]))
    return tasks, format_message("Here are your tasks sorted by priority and due time.")

def complete_task(title: str):
    for task in memory["tasks"]:
        if task["title"].lower() == title.lower():
            task["completed"] = True
            save_memory(memory)
            return format_message(f"Task '{title}' marked as completed!")
    return format_message(f"Task '{title}' not found.")

def suggest_next_task():
    pending = [t for t in memory["tasks"] if not t["completed"]]
    if not pending:
        return None, format_message("No pending tasks! 🎉")
    next_task = sorted(pending, key=lambda x: (x["priority"], x["due_time"]))[0]
    return next_task, format_message(f"Next task: '{next_task['title']}'")
